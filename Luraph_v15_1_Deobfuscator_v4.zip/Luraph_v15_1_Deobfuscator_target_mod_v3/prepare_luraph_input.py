#!/usr/bin/env python3
"""Prepare a Luraph v15 file for offline analysis by removing a leading bootstrap.

This helper does not execute Lua. It only copies the text beginning at the
Luraph protection marker into a new file. The input is never modified.
"""
import argparse
from pathlib import Path

MARKER = "-- This file was protected using Luraph Obfuscator v15.1"


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", help="original .lua/.luau file")
    parser.add_argument("output", help="path for prepared copy")
    args = parser.parse_args()

    source_path = Path(args.input)
    output_path = Path(args.output)
    source = source_path.read_text(encoding="utf-8", errors="replace")
    marker_at = source.find(MARKER)
    if marker_at < 0:
        parser.error(f"could not find expected marker: {MARKER!r}; input left unchanged")

    prepared = source[marker_at:]
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(prepared, encoding="utf-8")
    removed = len(source[:marker_at].encode("utf-8"))
    kept = len(prepared.encode("utf-8"))
    print(f"Prepared copy: {output_path}")
    print(f"Removed leading wrapper: {removed} bytes")
    print(f"Kept protected payload: {kept} bytes")
    print("No Lua code was executed; original input was not changed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
