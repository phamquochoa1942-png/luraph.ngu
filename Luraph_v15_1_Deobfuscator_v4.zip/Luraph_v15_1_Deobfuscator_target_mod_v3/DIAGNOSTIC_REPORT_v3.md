# Luraph v15 devirtualizer — mod v3 report

## Changes

1. **Numeric `for` bounds:** the symbolic interpreter now asks the lifter's reaching-value resolver for concrete `Reg`, `Upval`, and `Vararg` values. If needed, it folds a small whitelist of pure arithmetic expressions (`+`, `-`, `*`, `/`, floor division, modulo, power, unary minus). The normal loop interpreter then runs with the resolved numeric bounds.
2. **No guessing:** when any bound remains symbolic, the existing `numeric for with symbolic bounds` failure is preserved. `DEVIRT_TRACE_SYMBOLIC_FOR=1` prints the remaining expression types and values for diagnosis.
3. **Runtime-function stub diagnostics:** the tool records whether an opaque runtime function's proto table, captured proto, or original source node is present. Generated stubs include this diagnostic. It does **not** synthesize a pretend body when capture data is missing.
4. Added regression tests for resolved numeric loops, unresolved bounds, and missing runtime-function capture metadata.

## Verification

- `npm test`: **7/7 passed**.
- `python -m py_compile core/luasym.py core/obfuscators/luraph_v15/devirt.py`: passed.
- `luau-ast` syntax check of the generated output for sample `2153b779fa7a87f2`: passed; byte-for-byte golden comparison: passed.
- A fresh end-to-end check of the other samples did not complete within the execution window, so no claim is made that all golden samples were reverified for v3.

## Target-file limitation

The supplied `2264054913459885.lua` begins with a loader that calls `game:HttpGet` on a GitHub raw URL, followed by a large Luraph runtime line. Static analysis of the supplied file alone found **0 VM roots**. Preparing a copy by stripping the loader also found **0 VM roots / 0 functions**. The prior partial output with the 63 `numeric for with symbolic bounds` markers appears to depend on a dynamically loaded chunk that is not present as a local source file in this run. This package therefore improves the resolver and diagnostics, but does not claim that those 63 markers are reduced for the target.

The 13 `Luraph runtime function, not devirtualized` stubs are emitted where the capture has a function identifier but lacks the proto/body needed to lift it. A missing body cannot be restored by deleting its `error()` statement; doing so would hide a broken output. The new comments show whether the table/proto capture exists and help identify what additional trace data is missing.
