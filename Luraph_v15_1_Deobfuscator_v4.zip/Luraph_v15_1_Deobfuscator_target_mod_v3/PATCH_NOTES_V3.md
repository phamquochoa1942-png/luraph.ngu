# Mod v3 patch notes

- Numeric-for bounds can now be resolved from known register/upvalue/vararg facts and safely folded pure numeric expressions.
- Unknown numeric-for bounds remain explicit errors; there is no arbitrary one-iteration fallback.
- Opaque Luraph runtime function stubs now include capture metadata (whether a proto table, captured proto, or source node was available).
- Added regression tests covering numeric-loop resolution and unresolved runtime function diagnostics.
- See `DIAGNOSTIC_REPORT_v3.md` for verified results and limits.
