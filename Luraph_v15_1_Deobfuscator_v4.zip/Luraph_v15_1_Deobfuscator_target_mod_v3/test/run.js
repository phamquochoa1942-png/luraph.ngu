#!/usr/bin/env node
'use strict';

const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { spawnSync } = require('node:child_process');

const root = path.resolve(__dirname, '..');
const python = process.env.PYTHON || 'python3';
let passed = 0;

function test(name, fn) {
  try {
    fn();
    passed += 1;
    process.stdout.write(`[OK] ${name}\n`);
  } catch (err) {
    process.stderr.write(`[FAIL] ${name}: ${err && err.stack || err}\n`);
    process.exitCode = 1;
  }
}

function run(command, args, opts = {}) {
  return spawnSync(command, args, { cwd: root, encoding: 'utf8', ...opts });
}

test('Python naming regression: generated locals and semantic hints', () => {
  const code = String.raw`
import sys
sys.path.insert(0, 'core')
import names
for x in ('v1', 'n22', 'fn3', 'arg4', 'a2_1'):
    assert names.GENERATED.match(x), x
source = '''local v1 = Instance.new("Frame")
local n1 = game:GetService("Players")
local fn1 = function() return "RemoteEvent" end
local fn2 = function(player) player:Kick("bye") end
local v2 = Instance.new("Frame")
for v3, v4 in ipairs({1, 2}) do print(v3, v4) end
local v5 = workspace.Name
'''
out = names.rename_text(source)
for fragment in ('local frame =', 'local players =', 'local getRemoteEvent =',
                 'local kickPlayer =', 'local frame2 =', 'for i, item in ipairs',
                 'local name = workspace.Name'):
    assert fragment in out, (fragment, out)
for old in ('local v1', 'local n1', 'local fn1', 'local fn2', 'local v2', 'local v3', 'local v4', 'local v5'):
    assert old not in out, (old, out)
from obfuscators.luraph_v15.devirt import ProtoLifter
from luasym import Global, Reg, Index, Unsupported
lifter = ProtoLifter.__new__(ProtoLifter)
assert isinstance(lifter.index(Global('unresolvedTable'), Reg(2), None), Index)
try:
    lifter.index(51, Reg(2), None)
except Unsupported as exc:
    assert str(exc) == 'index 51', str(exc)
else:
    raise AssertionError('concrete scalar indexing must remain a safe failure')
`;
  const p = run(python, ['-c', code]);
  assert.equal(p.status, 0, `${p.stdout}\n${p.stderr}`);
});

test('opt-in opaque fallback preserves failing bit32 calls as runtime calls', () => {
  const code = String.raw`
import os, sys
os.environ['DEVIRT_OPAQUE_FAILING_BUILTINS'] = '1'
sys.path.insert(0, 'core')
from obfuscators.luraph_v15.devirt import ProtoLifter
from luasym import Builtin, Multi, TempTail
from ir import CallStmt
l = ProtoLifter.__new__(ProtoLifter)
l.vm = None
l.out = []
l.temp_prefix = 't'
l.tcount = 0
l.reg_gen = {}
l.war_saved = {}
l.reg_def_idx = {}
l.cur_it = None
l.ov_base = None
r = l.call_builtin(Builtin('bit32.bxor'), Multi([None, 7]), None, False)
assert isinstance(r, Multi) and isinstance(r.tail, TempTail), repr(r)
assert len(l.out) == 1 and isinstance(l.out[0], CallStmt), l.out
assert getattr(l, 'opaque_builtin_fallbacks', 0) == 1
# The collect-only path mutates this mapping before FunctionLifter.lift runs.
lf = ProtoLifter.__new__(ProtoLifter)
lf.init_facts = {}
lf.init_facts.update({('vararg', 1): ('c', 1)})
assert lf.init_facts[('vararg', 1)] == ('c', 1)
`;
  const p = run(python, ['-c', code]);
  assert.equal(p.status, 0, `${p.stdout}\n${p.stderr}`);
});

test('opt-in scalar index continuation preserves scalar receiver', () => {
  const code = String.raw`
import os, sys
os.environ['DEVIRT_OPAQUE_SCALAR_INDEX'] = '1'
sys.path.insert(0, 'core')
from obfuscators.luraph_v15.devirt import ProtoLifter
from luasym import Const, Index, Reg
from codegen import Renderer
l = ProtoLifter.__new__(ProtoLifter)
e = l.index(8, Reg(2), None)
assert isinstance(e, Index) and isinstance(e.obj, Const) and e.obj.v == 8, repr(e)
rendered = Renderer().expr(e)
assert rendered == '(8)[r2]', rendered
# Scalar writes follow the same opt-in policy and remain actual assignments.
l.out = []
l.reg_gen = {}
l.war_saved = {}
l.reg_def_idx = {}
l.cur_it = None
l.newindex(25, b'field', 4, None)
from ir import Assign
assert len(l.out) == 1 and isinstance(l.out[0], Assign), l.out
assert isinstance(l.out[0].target, Index), l.out[0]
assert Renderer().expr(l.out[0].target).startswith('(25).') or Renderer().expr(l.out[0].target).startswith('(25)['), Renderer().expr(l.out[0].target)
`;
  const p = run(python, ['-c', code]);
  assert.equal(p.status, 0, `${p.stdout}\n${p.stderr}`);
});

test('numeric-for bounds resolve from reaching facts and pure arithmetic', () => {
  const code = String.raw`
import sys
sys.path.insert(0, 'core')
from luasym import Interp, Scope, Reg, Const, Bin, Unsupported

class FakeLifter:
    def __init__(self, bounds):
        self.special = {}
        self.out = []
        self.bounds = bounds
    def _resolve_jval(self, value):
        if isinstance(value, Reg):
            return self.bounds.get(value.n)
        return None
    def _need_jreg(self, *values):
        pass
    def check_decision(self, value):
        pass
    def sym_binop(self, op, left, right):
        return Bin(op, left if hasattr(left, '__dict__') else Const(left),
                   right if hasattr(right, '__dict__') else Const(right))

local = lambda name: {'type': 'AstExprLocal', 'local': {'location': name, 'name': name}}
num = lambda value: {'type': 'AstExprConstantNumber', 'value': value}
node = {
  'type': 'AstStatFor',
  'from': {'type': 'AstExprBinary', 'op': 'Add', 'left': local('start'), 'right': num(1)},
  'to': local('finish'),
  'step': local('step'),
  'var': {'location': 'i', 'name': 'i'},
  'body': {'type': 'AstStatBlock', 'body': [{
    'type': 'AstStatCompoundAssign', 'op': 'Add', 'var': local('count'), 'value': num(1)
  }]}
}
lifter = FakeLifter({1: 1, 2: 4, 3: 1})
scope = Scope()
scope.vars.update({'start': Reg(1), 'finish': Reg(2), 'step': Reg(3), 'count': 0})
Interp(lifter).exec_stmt(node, scope)
assert scope.vars['count'] == 3, scope.vars['count']

# Unknown limits remain explicit failures rather than being guessed.
unknown = FakeLifter({})
scope2 = Scope()
scope2.vars.update({'start': Reg(10), 'finish': Reg(11), 'step': Reg(12)})
unknown_node = dict(node, **{'from': local('start'), 'to': local('finish'), 'step': local('step'),
                              'body': {'type': 'AstStatBlock', 'body': []}})
try:
    Interp(unknown).exec_stmt(unknown_node, scope2)
except Unsupported as exc:
    assert str(exc) == 'numeric for with symbolic bounds', str(exc)
else:
    raise AssertionError('unknown symbolic loop bounds must not be guessed')
`;
  const p = run(python, ['-c', code]);
  assert.equal(p.status, 0, `${p.stdout}\n${p.stderr}`);
});

test('unresolved shared functions carry capture diagnostics instead of guessed bodies', () => {
  const code = String.raw`
import sys
from types import SimpleNamespace
sys.path.insert(0, 'core')
from obfuscators.luraph_v15.devirt import ProtoLifter, OpaqueFn, SharedFn
l = ProtoLifter.__new__(ProtoLifter)
l.dump = SimpleNamespace(shared={}, shared_info={}, tables={}, cap_by_self={})
f = OpaqueFn('sample-runtime-fn')
f.pf_tid = 12345
expr = l._shared_fn_expr(f)
assert isinstance(expr, SharedFn), type(expr).__name__
assert l.dump.shared == {'sample-runtime-fn': 1}, l.dump.shared
info = l.dump.shared_info['sample-runtime-fn']
assert info['pf_tid'] == 12345
assert info['proto_table_present'] is False
assert info['proto_capture_present'] is False
assert info['source_node_present'] is False
`;
  const p = run(python, ['-c', code]);
  assert.equal(p.status, 0, `${p.stdout}\n${p.stderr}`);
});

test('envlog Luau parses with bundled luau-ast', () => {
  // AST output is large; discard it rather than truncating it via spawnSync maxBuffer.
  const p = spawnSync(path.join(root, 'bin', 'luau-ast'), ['runtime/envlog.luau'],
    { cwd: root, stdio: 'ignore' });
  assert.equal(p.status, 0, `luau-ast status: ${p.status}, signal: ${p.signal}`);
});

test('config globals are explicit and available to getrenv', () => {
  const source = fs.readFileSync(path.join(root, 'runtime', 'envlog.luau'), 'utf8');
  assert.match(source, /E\.settings\s*=\s*function\s*\(/);
  assert.match(source, /E\.UserSettings\s*=\s*function\s*\(/);
  assert.match(source, /settings,UserSettings/);
});

test('names: kickPlayer only for a pure Kick function; real names are not "generated"', () => {
  const code = [
    "import sys",
    "sys.path.insert(0, 'core')",
    "import names",
    "for x in ('bit32','utf8','md5','sha256','base64','vec3','writeu32','cframe2'):",
    "    assert not names.GENERATED.match(x), x",
    "for x in ('v12','n3','fn3','tbl10','flag4','str2','arg2_','a2_1'):",
    "    assert names.GENERATED.match(x), x",
    "src = 'local fn1 = function(p, a, b)\\n local x = a + b\\n if x > 5 then p:Kick(\"bye\") end\\n return x\\nend\\n' \\",
    "      'local fn2 = function(p) p:Kick(\"bye\") end\\n' \\",
    "      'local fn3 = function(p) local t = {} local function g() p:Kick(\"x\") end return t end\\n'",
    "out = names.rename_text(src)",
    "assert 'local kickPlayer = function(p) p:Kick' in out, out",
    "assert out.count('kickPlayer') == 1, out",
  ].join('\n');
  const p = run(python, ['-c', code]);
  assert.equal(p.status, 0, `${p.stdout}\n${p.stderr}`);
});

test('golden samples still match byte-for-byte', () => {
  const dir = path.join(root, 'samples_v15.1_deobfuscated');
  for (const id of ['2153b779fa7a87f2', '390ea6acb88b8f9f', 'cf96f658de290478', 'e20f3887d419069f']) {
    const out = path.join(require('node:os').tmpdir(), `golden_${id}.lua`);
    const p = run('node', ['deob.js', path.join(dir, `${id}_obfuscated.lua`), '-o', out],
      { env: { ...process.env, PYTHON_BIN: process.env.PYTHON_BIN || 'python3' }, timeout: 120000 });
    assert.equal(p.status, 0, `${id}: ${p.stderr}`);
    assert.equal(fs.readFileSync(out, 'utf8'), fs.readFileSync(path.join(dir, `${id}_Deobfuscated.lua`), 'utf8'), id);
  }
});

if (!process.exitCode) process.stdout.write(`\n${passed} test(s) passed.\n`);
