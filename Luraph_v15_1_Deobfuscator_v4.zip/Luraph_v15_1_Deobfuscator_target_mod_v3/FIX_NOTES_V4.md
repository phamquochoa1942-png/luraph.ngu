# v4 fixes (trên nền v3)

## Đã sửa (có test)
1. names.py: `kickPlayer` chỉ khi thân hàm là đúng 1 lệnh `x:Kick(...)` (v3 gán cho mọi hàm có chứa Kick).
2. names.py: `GENERATED` chỉ khớp tiền tố tool tự sinh (v, n, fn, flag, tbl, str, num, ret, tmp, arg).
   `bit32`, `utf8`, `md5`, `sha256`, `base64`, `vec3`, `writeu32` không còn bị coi là tên sinh tự động.
3. core/luasym.py: `DEVIRT_DBG_IDX=1` in giá trị mọi biến trong scope (kèm [5]/[4] của bảng) tại chỗ "index N".
4. test/run.js: thêm test kickPlayer/GENERATED và test 4 mẫu golden khớp từng byte (9/9 pass).

## Chưa sửa: "index N" (57 block, 58 stub trên 2264054913459885.lua)
Đo được: 37/61 lỗi ở chunk VM cột 138984, handler opcode 30 (nhánh else cuối của cây so sánh):
  local n,t,f = e[u], X[u], w[5]; local S = z(f[n], 425331368)
`w[5]` trả về số nguyên (vd 35) nên `f[n]` lỗi. Trong scope tại thời điểm lỗi KHÔNG có bảng nào có [5]==35;
các bảng trong scope có [5] là số nguyên (4, 20, 116, 99, 0) và [4] là số nguyên, tức là mảng operand,
không phải bảng proto (cần [4]=buffer, [5]=bảng vị trí hằng). Tham số m=51, w=50 là số nguyên.
Kết luận tạm: `w` bị gán nhầm giá trị (mảng operand/số) cho các proto này, hoặc nhánh này là đường
suy đoán mà proto thật không đi qua. Chưa chứng minh được cái nào.
Đã loại trừ: dup-param binding (gán theo vị trí), cap_fallback, maker_args theo tên (nhánh đó không chạy ở script này).
Bước tiếp: log trong Interp.getvar khi key nằm trong lf.special để xem `w` lấy từ đâu.

## Cập nhật: truy nguyên `w` (dùng DEVIRT_DBG_W=1 DEVIRT_DBG_IDX=1)
Số liệu trên 2264054913459885.lua (preset Configs), theo maker của VM:
| maker (cột)  | proto có w=#24 (w[5]=bảng #401) | proto có w=#105 (w[5]=int 0) |
|---|---|---|
| @124358 | 139 lần, lift bình thường | 58 lần -> các lỗi "index N" |
| @70335  | 132 lần, lift bình thường | 3 lần  -> các lỗi "index N" |
- #24 = đối tượng dùng chung {4=Buf, 5=bảng #401, 6=bảng #402, 7=true}: đúng cấu trúc handler opcode 30 cần.
- #105 = mảng số nguyên {5,0,7,5,0,7,8,34}: không có buffer ở [4], không có bảng ở [5].
- cap.w (do hook ghi lại lúc tạo closure) và scope.w đều là #105, tức là KHÔNG phải tool gán nhầm `w`:
  closure thật của các proto nhóm B mang w=#105. Handler opcode 30 mà thật sự chạy với w=#105 sẽ lỗi
  ngay cả trong VM thật. Kết luận: tool đang giải mã opcode = 30 cho proto nhóm B, nhưng VM thật không
  bao giờ chạy opcode 30 ở đó. Nghi ngờ lớn nhất: giải mã/overlay opcode (Overlay XOR in-place,
  khóa T trong `Z(e[P],(z(Z(T,...))))`) dùng trạng thái của nhóm A cho proto nhóm B,
  hoặc nhánh suy đoán không khả thi bị tính là lỗi cả block.
- Các stub nằm trong hàm script thật (UI, GetKeyBtn.MouseButton1Click, pcall/task.spawn...), không chỉ helper runtime.
Bước tiếp theo: với một proto nhóm B (vd #1435, #1479), in op giải mã được ở từng pc và so với op thật
trong trace chạy thật (envlog) để xem op giải mã sai ở đâu; kiểm tra Overlay cho nhóm B.
