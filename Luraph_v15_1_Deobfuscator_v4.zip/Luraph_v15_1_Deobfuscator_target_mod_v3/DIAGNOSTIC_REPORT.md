# Luraph v15 deobfuscator — target patch report (v2)

## Changes in this package

- `runtime/envlog.luau`: `settings()` / `UserSettings()` return safe proxy-backed tables for the analysis harness.
- `core/names.py`: improve inferred names for Roblox API results, constant-return helpers, `Kick`, and `ipairs` values.
- `core/obfuscators/luraph_v15/devirt.py`:
  - initialize `ProtoLifter.init_facts` in the constructor so collect-only walking can update the mapping before normal lifting starts;
  - add opt-in `DEVIRT_OPAQUE_FAILING_BUILTINS=1` handling for failing concrete `bit32.*` evaluation and failing or symbolic `buffer.read*` calls. These are emitted as actual runtime calls rather than immediately aborting the whole lifted block;
  - add opt-in `DEVIRT_OPAQUE_SCALAR_INDEX=1` handling for scalar receiver reads/writes. It emits the original indexing/store expression (e.g. `(8)[key]`) rather than reinterpreting a number as a table.
- `test/run.js`: adds tests for both opt-in fallbacks and the collect-only init-facts path.
- `README.md`: documents the experimental flags and their limitations.
- `prepare_luraph_input.py`: creates a separate payload-only copy after the known Luraph v15.1 marker; it does not run the leading remote-loader wrapper.
- `presets/configs_trace_only.luau`: optional placeholder `Configs["FPS Limit"] = 60` for the harness only.

The fallbacks are disabled by default. They preserve runtime operations, including runtime errors, but can leave symbolic values in the walker. They are diagnostic / partial-recovery tools, not a guarantee of a clean deobfuscation.

## Target file

- Input: `2264054913459885.lua`, 825,141 bytes, SHA-256 `c6686c3195c290e5d65fd2653e20b5cd0fc355c2aa51e0719dad08ab56e30f53`.
- The first 189 bytes are a `task.spawn` / `game:HttpGet` / `loadstring` wrapper pointing to a remote GitHub raw script. Analysis used a separate payload-only copy and did not execute that wrapper.
- Detected as Luraph v15 at confidence 1.00.

## Measured results

### No preset, resilient flags on, walk limit 10,000

Command environment: `DEVIRT_OPAQUE_FAILING_BUILTINS=1`, `DEVIRT_OPAQUE_SCALAR_INDEX=1`, `DEVIRT_WALK_LIMIT=10000`. The analysis run completed its lift stage in 18.1 seconds:

- 93 functions
- 62 unlifted blocks
- 63 `devirt:` markers
- output size about 134.7 KB
- `luau-ast` syntax check passed
- harness trace still reports `attempt to index nil with 'FPS Limit'` because the preset was not enabled.

The failure reason progressed from `index 0` to `numeric for with symbolic bounds`, but the count of stubs did **not** fall. This is a diagnostic advance, not proof of better semantic recovery.

### Matched comparison with the optional trace preset and walk limit 2,000

Both runs used the same input, preset, time budget, `--devirt-rounds 1`, and `DEVIRT_WALK_LIMIT=2000`.

| Metric | Flags off | Resilient flags on |
|---|---:|---:|
| Functions | 26 | 26 |
| Unlifted blocks | 15 | 15 |
| `devirt:` markers | 15 | 15 |
| Output bytes | 36,720 | 37,020 |
| `luau-ast` | pass | pass |

The marker counts are equal. With the flags on, the primary failure message advances from `index 0` to `numeric for with symbolic bounds`. The walk limit also makes this a deliberately partial output.

A preset-enabled run at the higher walk limit did not finish within the external run-time limit. No completed full-lift result is claimed for that configuration.

## Verification

- `npm test`: 5/5 passed.
- `python -m py_compile core/obfuscators/luraph_v15/devirt.py core/names.py prepare_luraph_input.py`: passed.
- Four small sample outputs (`2153b779fa7a87f2`, `390ea6acb88b8f9f`, `cf96f658de290478`, `e20f3887d419069f`) matched their existing golden files byte-for-byte and passed `luau-ast` syntax validation.
- Target output syntax validation passed. Syntax validity does not imply the remaining stubs have been recovered.

## Current blocker

The next repeated blocker is `numeric for with symbolic bounds`. The relevant loop bounds depend on values the walker cannot resolve. Executing one arbitrary iteration or deleting the stub would invent VM semantics, so this package leaves the failure explicit rather than silently guessing.
